// Hand Gesture Classification Model & Feature Matching
import { Landmark3D, normalizeLandmarks } from './landmarks';

export interface GesturePrediction {
  topChar: string;
  topConfidence: number;
  top3: { char: string; confidence: number }[];
}

export const ASL_CLASSES = [
  'A', 'B', 'C', 'D', 'E', 'L', 'V', 'W', 'Y', 'SPACE'
] as const;

export type ASLClass = typeof ASL_CLASSES[number];

export const GESTURE_DESCRIPTIONS: Record<string, string> = {
  'A': 'Fist with thumb resting along the side of index finger',
  'B': 'Open hand with four fingers straight up and thumb across palm',
  'C': 'Curved hand forming a "C" shape with all fingers and thumb',
  'D': 'Index finger pointing straight up, others curled touching thumb',
  'E': 'All fingers curled in tightly with thumb bent across bottom',
  'L': 'Thumb and index finger extended at right angle forming an "L"',
  'V': 'Index and middle fingers extended apart forming a "V" (peace)',
  'W': 'Index, middle, and ring fingers extended up spread apart',
  'Y': 'Thumb and pinky fingers extended out (hang loose/shaka)',
  'SPACE': 'Open flat hand with all fingers extended and spread'
};

/**
 * Calculates Euclidean distance between two 3D landmarks
 */
function dist(p1: Landmark3D, p2: Landmark3D): number {
  const dx = p1.x - p2.x;
  const dy = p1.y - p2.y;
  const dz = (p1.z || 0) - (p2.z || 0);
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

/**
 * Computes finger extension metrics from 21 MediaPipe landmarks
 * Finger tip vs PIP/MCP joints and wrist distance
 */
export function analyzeHandPose(landmarks: Landmark3D[]) {
  if (landmarks.length < 21) {
    return null;
  }

  const wrist = landmarks[0];

  // MCP joints: 1, 5, 9, 13, 17
  // Tips: 4 (thumb), 8 (index), 12 (middle), 16 (ring), 20 (pinky)
  // PIP joints: 2, 6, 10, 14, 18
  // DIP joints: 3, 7, 11, 15, 19

  // Hand scale reference (wrist to middle MCP)
  const palmScale = dist(wrist, landmarks[9]) || 0.2;

  // Finger tip distances from wrist
  const thumbTipDist = dist(wrist, landmarks[4]) / palmScale;
  const indexTipDist = dist(wrist, landmarks[8]) / palmScale;
  const middleTipDist = dist(wrist, landmarks[12]) / palmScale;
  const ringTipDist = dist(wrist, landmarks[16]) / palmScale;
  const pinkyTipDist = dist(wrist, landmarks[20]) / palmScale;

  // Extension ratios: tip distance to wrist compared to PIP distance to wrist
  const isThumbExtended = dist(wrist, landmarks[4]) > dist(wrist, landmarks[2]) * 1.15;
  const isIndexExtended = dist(wrist, landmarks[8]) > dist(wrist, landmarks[6]) * 1.18;
  const isMiddleExtended = dist(wrist, landmarks[12]) > dist(wrist, landmarks[10]) * 1.18;
  const isRingExtended = dist(wrist, landmarks[16]) > dist(wrist, landmarks[14]) * 1.18;
  const isPinkyExtended = dist(wrist, landmarks[20]) > dist(wrist, landmarks[18]) * 1.18;

  // Angle between thumb and index
  const thumbIndexDist = dist(landmarks[4], landmarks[8]) / palmScale;
  const indexMiddleDist = dist(landmarks[8], landmarks[12]) / palmScale;
  const middleRingDist = dist(landmarks[12], landmarks[16]) / palmScale;
  const ringPinkyDist = dist(landmarks[16], landmarks[20]) / palmScale;
  const thumbPinkyDist = dist(landmarks[4], landmarks[20]) / palmScale;

  // Check C-shape curvature (all fingers curled moderately in arc)
  const isCShaped =
    !isIndexExtended &&
    dist(landmarks[8], landmarks[5]) > 0.4 * palmScale &&
    thumbIndexDist > 0.5 &&
    thumbIndexDist < 1.3 &&
    dist(landmarks[4], landmarks[8]) > 0.3 * palmScale;

  return {
    palmScale,
    extensions: {
      thumb: isThumbExtended ? 1 : 0,
      index: isIndexExtended ? 1 : 0,
      middle: isMiddleExtended ? 1 : 0,
      ring: isRingExtended ? 1 : 0,
      pinky: isPinkyExtended ? 1 : 0,
    },
    distances: {
      thumbTipDist,
      indexTipDist,
      middleTipDist,
      ringTipDist,
      pinkyTipDist,
      thumbIndexDist,
      indexMiddleDist,
      middleRingDist,
      ringPinkyDist,
      thumbPinkyDist,
    },
    isCShaped
  };
}

/**
 * Predicts ASL gesture from raw or normalized 21 hand landmarks
 * Applies feature normalization, geometry scoring, and softmax output
 */
export function classifyGesture(landmarks: Landmark3D[]): GesturePrediction {
  const analysis = analyzeHandPose(landmarks);
  if (!analysis) {
    return {
      topChar: 'UNKNOWN',
      topConfidence: 0,
      top3: []
    };
  }

  const { extensions, distances, isCShaped } = analysis;
  const rawScores: Record<ASLClass, number> = {
    'A': 0.05,
    'B': 0.05,
    'C': 0.05,
    'D': 0.05,
    'E': 0.05,
    'L': 0.05,
    'V': 0.05,
    'W': 0.05,
    'Y': 0.05,
    'SPACE': 0.05,
  };

  // 1. Gesture 'L': Thumb and Index extended, Middle/Ring/Pinky folded
  if (extensions.index && extensions.thumb && !extensions.middle && !extensions.ring && !extensions.pinky) {
    if (distances.thumbIndexDist > 0.7) {
      rawScores['L'] += 4.5;
    }
  }

  // 2. Gesture 'V': Index and Middle extended, Thumb folded, Ring/Pinky folded
  if (extensions.index && extensions.middle && !extensions.ring && !extensions.pinky) {
    if (distances.indexMiddleDist > 0.25) {
      rawScores['V'] += 4.2;
    } else {
      rawScores['V'] += 3.5;
    }
  }

  // 3. Gesture 'W': Index, Middle, and Ring extended, Pinky folded
  if (extensions.index && extensions.middle && extensions.ring && !extensions.pinky) {
    rawScores['W'] += 4.4;
  }

  // 4. Gesture 'B': All 4 fingers extended up (Index, Middle, Ring, Pinky), Thumb across palm
  if (extensions.index && extensions.middle && extensions.ring && extensions.pinky) {
    if (distances.thumbTipDist < 1.3 || distances.thumbIndexDist < 0.6) {
      rawScores['B'] += 4.2;
    } else {
      rawScores['SPACE'] += 3.8; // Open spread hand
    }
  }

  // 5. Gesture 'SPACE': All 5 fingers extended and spread wide
  if (extensions.thumb && extensions.index && extensions.middle && extensions.ring && extensions.pinky) {
    if (distances.thumbIndexDist > 0.65) {
      rawScores['SPACE'] += 4.5;
    }
  }

  // 6. Gesture 'Y': Thumb and Pinky extended, Index/Middle/Ring curled
  if (extensions.thumb && extensions.pinky && !extensions.index && !extensions.middle && !extensions.ring) {
    if (distances.thumbPinkyDist > 1.1) {
      rawScores['Y'] += 4.6;
    }
  }

  // 7. Gesture 'D': Only Index extended, Middle/Ring/Pinky curled touching thumb
  if (extensions.index && !extensions.middle && !extensions.ring && !extensions.pinky && !extensions.thumb) {
    rawScores['D'] += 4.2;
  }

  // 8. Gesture 'A': Fist with thumb resting alongside index (all 4 curled)
  if (!extensions.index && !extensions.middle && !extensions.ring && !extensions.pinky) {
    if (distances.thumbTipDist > 0.7 && distances.thumbIndexDist > 0.2) {
      rawScores['A'] += 3.8;
    }
    // 9. Gesture 'E': All 4 curled tightly, thumb folded across bottom
    if (distances.thumbTipDist < 0.8 && distances.indexTipDist < 0.85) {
      rawScores['E'] += 3.7;
    }
  }

  // 10. Gesture 'C': Curved fingers forming C shape
  if (isCShaped && !extensions.index && !extensions.middle) {
    rawScores['C'] += 3.6;
  }

  // Compute Softmax probabilities
  const keys = Object.keys(rawScores) as ASLClass[];
  const exps = keys.map(k => Math.exp(rawScores[k]));
  const sumExp = exps.reduce((a, b) => a + b, 0);
  const probs: { char: string; confidence: number }[] = keys.map((k, i) => ({
    char: k,
    confidence: exps[i] / sumExp
  }));

  // Sort descending
  probs.sort((a, b) => b.confidence - a.confidence);

  return {
    topChar: probs[0].char,
    topConfidence: probs[0].confidence,
    top3: probs.slice(0, 3)
  };
}

/**
 * Synthesizes 21 3D hand landmarks matching the python generate_dataset.py logic
 * for quick testing, snapshot simulation, or offline training.
 */
export function synthesizeHandSkeleton(label: ASLClass, noiseStd: number = 0.015): Landmark3D[] {
  const BASE_GESTURES: Record<string, { thumb: number; index: number; middle: number; ring: number; pinky: number }> = {
    "A": { thumb: 0.3, index: 0.0, middle: 0.0, ring: 0.0, pinky: 0.0 },
    "B": { thumb: 0.0, index: 1.0, middle: 1.0, ring: 1.0, pinky: 1.0 },
    "C": { thumb: 0.5, index: 0.5, middle: 0.5, ring: 0.5, pinky: 0.5 },
    "D": { thumb: 0.2, index: 1.0, middle: 0.2, ring: 0.2, pinky: 0.2 },
    "E": { thumb: 0.1, index: 0.2, middle: 0.2, ring: 0.2, pinky: 0.2 },
    "L": { thumb: 1.0, index: 1.0, middle: 0.0, ring: 0.0, pinky: 0.0 },
    "V": { thumb: 0.0, index: 1.0, middle: 1.0, ring: 0.0, pinky: 0.0 },
    "W": { thumb: 0.0, index: 1.0, middle: 1.0, ring: 1.0, pinky: 0.0 },
    "Y": { thumb: 1.0, index: 0.0, middle: 0.0, ring: 0.0, pinky: 1.0 },
    "SPACE": { thumb: 0.8, index: 0.8, middle: 0.8, ring: 0.8, pinky: 0.8 },
  };

  const poseSpec = BASE_GESTURES[label] || BASE_GESTURES["A"];
  const landmarks: Landmark3D[] = new Array(21).fill(null).map(() => ({ x: 0, y: 0, z: 0 }));

  // Landmark 0: Wrist at base [0.5, 0.8, 0.0]
  landmarks[0] = { x: 0.5, y: 0.8, z: 0.0 };

  const mcpX = [0.42, 0.46, 0.50, 0.54, 0.58];
  const mcpY = [0.72, 0.60, 0.58, 0.60, 0.63];

  const fingers = ["thumb", "index", "middle", "ring", "pinky"] as const;
  const fingerIndices = [
    [1, 2, 3, 4],       // Thumb
    [5, 6, 7, 8],       // Index
    [9, 10, 11, 12],    // Middle
    [13, 14, 15, 16],   // Ring
    [17, 18, 19, 20],   // Pinky
  ];

  for (let fIdx = 0; fIdx < fingers.length; fIdx++) {
    const finger = fingers[fIdx];
    const ext = poseSpec[finger];
    const jointIds = fingerIndices[fIdx];
    const baseX = mcpX[fIdx];
    const baseY = mcpY[fIdx];

    if (finger === "thumb") {
      for (let step = 0; step < jointIds.length; step++) {
        const factor = (step + 1) * 0.05;
        const jId = jointIds[step];
        if (ext > 0.5) {
          landmarks[jId] = { x: baseX - factor * 1.5, y: baseY - factor * 0.5, z: -factor * 0.2 };
        } else {
          landmarks[jId] = { x: baseX + factor * 0.4, y: baseY - factor * 0.3, z: factor * 0.3 };
        }
      }
    } else {
      for (let step = 0; step < jointIds.length; step++) {
        const factor = (step + 1) * 0.06;
        const jId = jointIds[step];
        if (ext >= 0.8) {
          landmarks[jId] = { x: baseX, y: baseY - factor * 1.2, z: -factor * 0.1 };
        } else if (ext >= 0.4) {
          const curve = Math.sin((step + 1) * Math.PI / 4) * 0.04;
          landmarks[jId] = { x: baseX + curve, y: baseY - factor * 0.6, z: factor * 0.2 };
        } else {
          landmarks[jId] = { x: baseX, y: baseY + factor * 0.4, z: factor * 0.3 };
        }
      }
    }
  }

  // Add subtle random variation & noise
  for (let i = 0; i < 21; i++) {
    landmarks[i].x += (Math.random() - 0.5) * noiseStd * 2;
    landmarks[i].y += (Math.random() - 0.5) * noiseStd * 2;
    landmarks[i].z += (Math.random() - 0.5) * noiseStd * 2;
  }

  return landmarks;
}
