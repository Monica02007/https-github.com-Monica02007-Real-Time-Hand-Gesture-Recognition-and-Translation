import React from 'react';
import { X, BookOpen } from 'lucide-react';
import { ASL_CLASSES, GESTURE_DESCRIPTIONS } from '../utils/model';

interface ASLGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ASLGuideModal: React.FC<ASLGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">ASL Gesture Reference Guide</h3>
              <p className="text-xs text-slate-500">Supported American Sign Language gestures & hand configurations</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-6 overflow-y-auto space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {ASL_CLASSES.map((sign) => (
              <div
                key={sign}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-blue-50/40 hover:border-blue-200 transition-colors flex items-start gap-3"
              >
                <div className="w-10 h-10 rounded-lg bg-blue-600 text-white flex-shrink-0 flex items-center justify-center font-black text-lg shadow-sm">
                  {sign}
                </div>
                <div>
                  <div className="font-bold text-slate-800 text-sm">
                    {sign === 'SPACE' ? '␣ SPACE (Word Break)' : `Sign "${sign}"`}
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    {GESTURE_DESCRIPTIONS[sign]}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>21 MediaPipe hand landmarks with 3D wrist normalization</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
